"""Maze Generator module.

This module provides the MazeGenerator class for creating random mazes
using DFS, Kruskal, or Wilson algorithms, with A* pathfinding.

This file is auto-generated from src/a_maze_ing sources.
Do not edit directly - modify the source files instead.
"""

import random
from collections.abc import Callable
from enum import Enum, auto
from heapq import heappush, heappop
from random import choice as random_choice
from random import choice as rd_choice
from random import shuffle as random_shuffle
from mazegen.cell import Cell, CellState


# =============================================================================
# FT Pattern (from algorithms/ft_pattern.py)
# =============================================================================

_FT_PATTERN = [
    [1, 0, 0, 0, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 0, 1, 1, 1],
    [0, 0, 1, 0, 1, 0, 0],
    [0, 0, 1, 0, 1, 1, 1]
]

_FT_PATTERN_WARNED = False


def where_is_ft_pattern(grid: list[list[Cell]]) -> list[tuple[int, int]]:
    """Compute the coordinates for the fixed '42' pattern.

    Args:
        grid: 2D maze grid.

    Returns:
        List of coordinates to mark as the 42 pattern. Empty if too small.
    """
    if len(grid) < 7 or len(grid[0]) < 9:
        global _FT_PATTERN_WARNED
        if not _FT_PATTERN_WARNED:
            print("Error: Maze too small for '42' pattern, skipping pattern.")
            _FT_PATTERN_WARNED = True
        return []
    result = []
    pattern_top_left = (len(grid[0]) / 2 - 3, len(grid) / 2 - 2)
    for y in range(len(_FT_PATTERN)):
        for x in range(len(_FT_PATTERN[y])):
            top_left_x, top_left_y = pattern_top_left
            if _FT_PATTERN[y][x] == 1:
                result.append((int(top_left_x + x), int(top_left_y + y)))
    return result


# =============================================================================
# Grid Helpers (from algorithms/grid_utils.py)
# =============================================================================

def generate_full_grid(
        width: int,
        height: int
) -> tuple[list[list[Cell]], set[tuple[int, int]]]:
    """Create a grid filled with closed walls and mark the 42 pattern.

    Args:
        width: Number of columns.
        height: Number of rows.

    Returns:
        Tuple of (grid, pattern_positions).
    """
    grid = [
        [
            Cell(
                CellState.UNVISITED,
                True, True, True, True,
                (x, y)
            ) for x in range(width)
        ] for y in range(height)
    ]
    pattern_positions = set(where_is_ft_pattern(grid))
    for x, y in pattern_positions:
        grid[y][x].state = CellState.VISITED
    return grid, pattern_positions


def get_neighbors(
        coordinates: tuple[int, int],
        grid: list[list[Cell]],
        blocked: set[tuple[int, int]] | None = None
) -> list[Cell]:
    """Return neighboring cells, excluding blocked positions.

    Args:
        coordinates: Cell coordinates as (x, y).
        grid: 2D maze grid.
        blocked: Optional set of blocked positions.

    Returns:
        List of neighboring cells.
    """
    x, y = coordinates
    neighbors = []
    height = len(grid)
    width = len(grid[0]) if height > 0 else 0
    blocked_positions = blocked or set()

    if y > 0 and (x, y - 1) not in blocked_positions:
        neighbors.append(grid[y - 1][x])
    if y < height - 1 and (x, y + 1) not in blocked_positions:
        neighbors.append(grid[y + 1][x])
    if x > 0 and (x - 1, y) not in blocked_positions:
        neighbors.append(grid[y][x - 1])
    if x < width - 1 and (x + 1, y) not in blocked_positions:
        neighbors.append(grid[y][x + 1])

    return neighbors


def remove_walls_between(cell1: Cell, cell2: Cell) -> None:
    """Remove the walls between two adjacent cells.

    Args:
        cell1: First cell.
        cell2: Second cell (adjacent).
    """
    x1, y1 = cell1.coordinates
    x2, y2 = cell2.coordinates

    if x1 == x2:
        if y2 < y1:
            cell1.north = False
            cell2.south = False
        else:
            cell1.south = False
            cell2.north = False
    elif y1 == y2:
        if x2 < x1:
            cell1.west = False
            cell2.east = False
        else:
            cell1.east = False
            cell2.west = False


# =============================================================================
# Flaw Maze (from maze/flaw.py)
# =============================================================================

class CardinalPoint(Enum):
    """Cardinal directions used for wall manipulation."""

    NORTH = auto()
    SOUTH = auto()
    EAST = auto()
    WEST = auto()


def _get_neighbors(
    cell: Cell,
    grid: list[list[Cell]]
) -> dict[CardinalPoint, Cell]:
    """Return neighboring cells indexed by direction.

    Args:
        cell: Center cell.
        grid: 2D maze grid.

    Returns:
        Mapping from direction to adjacent cell.
    """
    x, y = cell.coordinates
    neighbors = {}
    height = len(grid)
    width = len(grid[0]) if height > 0 else 0

    if y > 0 and grid[y - 1][x]:
        neighbors[CardinalPoint.NORTH] = grid[y - 1][x]
    if y < height - 1 and grid[y + 1][x]:
        neighbors[CardinalPoint.SOUTH] = grid[y + 1][x]
    if x > 0 and grid[y][x - 1]:
        neighbors[CardinalPoint.WEST] = grid[y][x - 1]
    if x < width - 1 and grid[y][x + 1]:
        neighbors[CardinalPoint.EAST] = grid[y][x + 1]

    return neighbors


def _wall_breakable_toward(
    grid: list[list[Cell]],
    cell: Cell,
    direction: CardinalPoint
) -> bool:
    """Check if a wall can be removed toward a direction.

    Args:
        grid: 2D maze grid.
        cell: Cell to consider.
        direction: Direction to test.

    Returns:
        True if the wall can be removed without breaking constraints.
    """
    if cell.coordinates in where_is_ft_pattern(grid):
        return False
    neighbors = _get_neighbors(cell, grid)
    for direction in neighbors:
        if neighbors[direction].coordinates in where_is_ft_pattern(grid):
            return False

    match direction:
        case CardinalPoint.NORTH:
            if CardinalPoint.NORTH not in neighbors:
                return False
            if not neighbors[CardinalPoint.NORTH].south:
                return False
        case CardinalPoint.SOUTH:
            if CardinalPoint.SOUTH not in neighbors:
                return False
            if not neighbors[CardinalPoint.SOUTH].north:
                return False
        case CardinalPoint.EAST:
            if CardinalPoint.EAST not in neighbors:
                return False
            if not neighbors[CardinalPoint.EAST].west:
                return False
        case CardinalPoint.WEST:
            if CardinalPoint.WEST not in neighbors:
                return False
            if not neighbors[CardinalPoint.WEST].east:
                return False

    return True


def _remove_walls_toward(
    grid: list[list[Cell]],
    cell: Cell,
    direction: CardinalPoint
) -> None:
    """Remove walls between the given cell and its neighbor.

    Args:
        grid: 2D maze grid.
        cell: Cell to modify.
        direction: Direction of the neighbor.
    """
    x, y = cell.coordinates
    height = len(grid)
    width = len(grid[0]) if height > 0 else 0

    match direction:
        case CardinalPoint.NORTH:
            if y > 0:
                cell.north = False
                grid[y - 1][x].south = False
        case CardinalPoint.SOUTH:
            if y < height - 1:
                cell.south = False
                grid[y + 1][x].north = False
        case CardinalPoint.EAST:
            if x < width - 1:
                cell.east = False
                grid[y][x + 1].west = False
        case CardinalPoint.WEST:
            if x > 0:
                cell.west = False
                grid[y][x - 1].east = False


def flaw_maze(
    maze: list[list[Cell]],
    on_step: Callable[[list[list[Cell]]], None] | None = None
) -> None:
    """Introduce flaws by breaking additional walls.

    Args:
        maze: 2D maze grid to modify in-place.
        on_step: Optional callback called after each break.
    """
    walls_to_break: int = len(maze) * len(maze[0]) // 7
    iterations_remaining: int = 1500

    while walls_to_break > 0 and iterations_remaining > 0:
        rd_cell: Cell = random_choice(random_choice(maze))
        rd_direction = random_choice(list(CardinalPoint))

        if _wall_breakable_toward(maze, rd_cell, rd_direction):
            _remove_walls_toward(maze, rd_cell, rd_direction)
            walls_to_break -= 1
            if on_step:
                on_step(maze)

        iterations_remaining -= 1


# =============================================================================
# DFS Algorithm (from algorithms/dfs.py)
# =============================================================================

def generate_dfs(
        config: dict[str, object],
        on_step: Callable[[list[list[Cell]]], None] | None = None
) -> list[list[Cell]]:
    """Generate a perfect maze using recursive backtracker (DFS).

    Args:
        config: Configuration dictionary with WIDTH, HEIGHT, ENTRY keys.
        on_step: Optional callback called after each carving step.

    Returns:
        Generated maze grid.
    """
    entry = config["ENTRY"]
    assert isinstance(entry, tuple)
    x, y = entry
    width = config["WIDTH"]
    height = config["HEIGHT"]
    assert isinstance(width, int)
    assert isinstance(height, int)
    grid, _ = generate_full_grid(width, height)
    current = grid[y][x]
    current.state = CellState.VISITED
    stack = [current]
    if on_step:
        on_step(grid)

    while stack:
        current = stack[-1]
        neighbors = [nb for nb in get_neighbors(current.coordinates, grid)
                     if nb.state != CellState.VISITED]

        if neighbors:
            next_cell = random_choice(neighbors)
            remove_walls_between(current, next_cell)
            next_cell.state = CellState.VISITED
            stack.append(next_cell)
            if on_step:
                on_step(grid)
        else:
            stack.pop()

    return grid


# =============================================================================
# Kruskal Algorithm (from algorithms/kruskal.py)
# =============================================================================

class _DisjointSet:
    """Disjoint-set (union-find) structure for Kruskal."""

    def __init__(self, items: list[tuple[int, int]]) -> None:
        """Initialize the disjoint set with individual items.

        Args:
            items: Items to store, keyed by coordinates.
        """
        self.parent = {item: item for item in items}
        self.rank = {item: 0 for item in items}

    def find(self, item: tuple[int, int]) -> tuple[int, int]:
        """Find the representative for an item.

        Args:
            item: Item to find.

        Returns:
            Root representative for the item.
        """
        parent = self.parent[item]
        if parent != item:
            self.parent[item] = self.find(parent)
        return self.parent[item]

    def union(self, a: tuple[int, int], b: tuple[int, int]) -> bool:
        """Union two sets if they are disjoint.

        Args:
            a: First item.
            b: Second item.

        Returns:
            True if a union was performed, False if already connected.
        """
        root_a = self.find(a)
        root_b = self.find(b)
        if root_a == root_b:
            return False
        rank_a = self.rank[root_a]
        rank_b = self.rank[root_b]
        if rank_a < rank_b:
            self.parent[root_a] = root_b
        elif rank_a > rank_b:
            self.parent[root_b] = root_a
        else:
            self.parent[root_b] = root_a
            self.rank[root_a] += 1
        return True


def _get_edges(grid: list[list[Cell]]) -> list[tuple[Cell, Cell]]:
    """Collect candidate edges between adjacent unvisited cells.

    Args:
        grid: 2D maze grid.

    Returns:
        List of cell pairs representing edges.
    """
    edges: list[tuple[Cell, Cell]] = []
    height = len(grid)
    width = len(grid[0]) if height > 0 else 0

    for y in range(height):
        for x in range(width):
            cell = grid[y][x]
            if cell.state == CellState.VISITED:
                continue
            if y + 1 < height:
                neighbor = grid[y + 1][x]
                if neighbor.state != CellState.VISITED:
                    edges.append((cell, neighbor))
            if x + 1 < width:
                neighbor = grid[y][x + 1]
                if neighbor.state != CellState.VISITED:
                    edges.append((cell, neighbor))

    return edges


def generate_kruskal(
        config: dict[str, object],
        on_step: Callable[[list[list[Cell]]], None] | None = None
) -> list[list[Cell]]:
    """Generate a perfect maze using Kruskal's algorithm.

    Args:
        config: Configuration dictionary with WIDTH and HEIGHT keys.
        on_step: Optional callback called after each carving step.

    Returns:
        Generated maze grid.
    """
    width = config["WIDTH"]
    height = config["HEIGHT"]
    assert isinstance(width, int)
    assert isinstance(height, int)

    grid, _ = generate_full_grid(width, height)
    edges = _get_edges(grid)
    random_shuffle(edges)

    items = [
        cell.coordinates
        for row in grid
        for cell in row
        if cell.state != CellState.VISITED
    ]
    disjoint_set = _DisjointSet(items)

    if on_step:
        on_step(grid)

    for cell1, cell2 in edges:
        if disjoint_set.union(cell1.coordinates, cell2.coordinates):
            remove_walls_between(cell1, cell2)
            if on_step:
                on_step(grid)

    return grid


# =============================================================================
# Wilson Algorithm (from algorithms/wilson.py)
# =============================================================================

def _has_unvisited(grid: list[list[Cell]]) -> bool:
    """Check whether the grid contains unvisited cells.

    Args:
        grid: 2D maze grid.

    Returns:
        True if any cell is unvisited, otherwise False.
    """
    return any(
        cell.state == CellState.UNVISITED
        for row in grid
        for cell in row
    )


def _get_random_unvisited(grid: list[list[Cell]]) -> Cell:
    """Pick a random unvisited cell.

    Args:
        grid: 2D maze grid.

    Returns:
        A randomly selected unvisited cell.
    """
    unvisited = [
        cell for row in grid
        for cell in row
        if cell.state == CellState.UNVISITED
    ]
    return rd_choice(unvisited)


def generate_wilson(
        config: dict[str, object],
        on_step: Callable[[list[list[Cell]]], None] | None = None
        ) -> list[list[Cell]]:
    """Generate a perfect maze using Wilson's algorithm.

    Args:
        config: Configuration dictionary with WIDTH and HEIGHT keys.
        on_step: Optional callback called after each carving step.

    Returns:
        Generated maze grid.
    """
    width: int = int(config["WIDTH"])
    height: int = int(config["HEIGHT"])
    assert isinstance(width, int)
    assert isinstance(height, int)
    grid, pattern_positions = generate_full_grid(width, height)

    random_cell_in_maze: Cell = _get_random_unvisited(grid)
    random_cell_in_maze.state = CellState.IN_MAZE

    if on_step:
        on_step(grid)

    while _has_unvisited(grid):
        current_cell: Cell = _get_random_unvisited(grid)
        path: list[Cell] = [current_cell]
        while (current_cell.state != CellState.IN_MAZE):
            neighbors = get_neighbors(
                current_cell.coordinates,
                grid,
                blocked=pattern_positions
            )
            if not neighbors:
                break
            next_cell: Cell = rd_choice(neighbors)
            if next_cell in path:
                index = path.index(next_cell)
                path = path[:index + 1]
            else:
                path.append(next_cell)
            current_cell = next_cell

        if current_cell.state == CellState.IN_MAZE:
            for i in range(len(path) - 1):
                remove_walls_between(path[i], path[i + 1])
                if on_step:
                    on_step(grid)
            for cells in path:
                cells.state = CellState.IN_MAZE

    return grid


# =============================================================================
# A* Pathfinding (from algorithms/a_star.py)
# =============================================================================

def _manhattan_distance(pos: tuple[int, int], goal: tuple[int, int]) -> int:
    """Compute the Manhattan distance between two coordinates.

    Args:
        pos: Current position as (x, y).
        goal: Target position as (x, y).

    Returns:
        Manhattan distance between the two points.
    """
    return abs(pos[0] - goal[0]) + abs(pos[1] - goal[1])


def _get_accessible_neighbors(
        cell: Cell, grid: list[list[Cell]]
) -> list[tuple[Cell, str]]:
    """Return accessible neighboring cells and the move direction.

    Args:
        cell: Current cell.
        grid: 2D maze grid.

    Returns:
        List of (neighbor_cell, direction) tuples with directions in N/E/S/W.
    """
    x, y = cell.coordinates
    height = len(grid)
    width = len(grid[0]) if height > 0 else 0
    neighbors = []

    if not cell.north and y > 0:
        neighbors.append((grid[y - 1][x], 'N'))
    if not cell.south and y < height - 1:
        neighbors.append((grid[y + 1][x], 'S'))
    if not cell.west and x > 0:
        neighbors.append((grid[y][x - 1], 'W'))
    if not cell.east and x < width - 1:
        neighbors.append((grid[y][x + 1], 'E'))

    return neighbors


def a_star(
        entry: tuple[int, int],
        exit: tuple[int, int],
        grid: list[list[Cell]],
        on_step: Callable[
            [tuple[int, int], set[tuple[int, int]], set[tuple[int, int]], str],
            None
        ] | None = None
) -> str:
    """Find the shortest path between entry and exit using A*.

    Args:
        entry: Entry coordinates as (x, y).
        exit: Exit coordinates as (x, y).
        grid: 2D maze grid.
        on_step: Optional callback called on each exploration step.

    Returns:
        Path string composed of N/E/S/W steps. Empty string if no path.
    """
    if not grid or not grid[0]:
        return ""

    def reconstruct_path(
            came_from: dict[tuple[int, int], tuple[tuple[int, int], str]],
            current: tuple[int, int]
    ) -> str:
        """Reconstruct the path string from the parent map.

        Args:
            came_from: Mapping from position to (previous, direction).
            current: Current position to backtrack from.

        Returns:
            Path string from entry to current.
        """
        steps: list[str] = []
        while current in came_from:
            previous, direction = came_from[current]
            steps.append(direction)
            current = previous
        steps.reverse()
        return "".join(steps)

    counter = 0
    open_set: list[tuple[int, int, tuple[int, int]]] = []
    heappush(open_set, (0, counter, entry))
    open_positions = {entry}

    g_score = {entry: 0}
    came_from: dict[tuple[int, int], tuple[tuple[int, int], str]] = {}

    closed_set: set[tuple[int, int]] = set()

    while open_set:
        _, _, current_pos = heappop(open_set)

        if current_pos in closed_set:
            continue
        open_positions.discard(current_pos)
        path = reconstruct_path(came_from, current_pos)

        if current_pos == exit:
            if on_step:
                on_step(
                    current_pos,
                    set(open_positions),
                    closed_set | {current_pos},
                    path
                )
            return path

        closed_set.add(current_pos)

        current_x, current_y = current_pos
        current_cell = grid[current_y][current_x]

        for neighbor_cell, direction in (
                _get_accessible_neighbors(current_cell, grid)
        ):
            neighbor_pos = neighbor_cell.coordinates

            if neighbor_pos in closed_set:
                continue

            tentative_g = g_score[current_pos] + 1

            if (neighbor_pos not in g_score or
                    tentative_g < g_score[neighbor_pos]):
                g_score[neighbor_pos] = tentative_g
                came_from[neighbor_pos] = (current_pos, direction)
                f_score = tentative_g + _manhattan_distance(neighbor_pos, exit)
                counter += 1
                heappush(
                    open_set,
                    (f_score, counter, neighbor_pos)
                )
                open_positions.add(neighbor_pos)

        if on_step:
            on_step(
                current_pos,
                set(open_positions),
                set(closed_set),
                path
            )

    return ""


# =============================================================================
# MazeGenerator - Main class (from mazegen_wrapper.py)
# =============================================================================

class MazeGenerator:
    """A configurable maze generator supporting multiple algorithms.

    This class wraps the DFS, Kruskal, and Wilson generation algorithms and
    A* solver.
    Generated mazes are perfect mazes (exactly one path between any two cells).

    Attributes:
        width: Number of cells horizontally.
        height: Number of cells vertically.
        seed: Random seed for reproducibility.
        algorithm: 'DFS', 'KRUSKAL', or 'WILSON'.
        perfect: Whether to generate a perfect maze (no loops).
        maze: The generated maze grid (None until generate() is called).

    Example:
        >>> from mazegen import MazeGenerator
        >>> gen = MazeGenerator(width=20, height=15, seed=42)
        >>> maze = gen.generate()
        >>> path = gen.solve((0, 0), (19, 14))
    """

    def __init__(
        self,
        width: int = 20,
        height: int = 15,
        seed: int | None = None,
        algorithm: str = "DFS",
        perfect: bool = True
    ) -> None:
        if width < 1:
            raise ValueError(f"Width must be at least 1, got {width}")
        if height < 1:
            raise ValueError(f"Height must be at least 1, got {height}")
        if algorithm.upper() not in ("DFS", "KRUSKAL", "WILSON"):
            raise ValueError(
                "Algorithm must be 'DFS', "
                f"'KRUSKAL', or 'WILSON', got {algorithm}"
            )

        self.width = width
        self.height = height
        self.seed = seed
        self.algorithm = algorithm.upper()
        self.perfect = perfect
        self.maze: list[list[Cell]] | None = None
        self._pattern_cells: list[tuple[int, int]] = []

    def generate(
        self,
        entry: tuple[int, int] | None = None,
        on_step: Callable[[list[list[Cell]]], None] | None = None
    ) -> list[list[Cell]]:
        """Generate a new maze."""
        if entry is None:
            entry = (0, 0)

        if not (0 <= entry[0] < self.width and 0 <= entry[1] < self.height):
            raise ValueError(f"Entry {entry} out of bounds")

        if self.seed is not None:
            random.seed(self.seed)

        config = {
            "WIDTH": self.width,
            "HEIGHT": self.height,
            "ENTRY": entry,
        }

        if self.algorithm == "KRUSKAL":
            self.maze = generate_kruskal(config, on_step)
        elif self.algorithm == "WILSON":
            self.maze = generate_wilson(config, on_step)
        else:
            self.maze = generate_dfs(config, on_step)

        if self.maze and not self.perfect:
            flaw_maze(self.maze, on_step=on_step)

        # Compute pattern cells
        if self.maze:
            self._pattern_cells = where_is_ft_pattern(self.maze)

        return self.maze

    def solve(
        self,
        entry: tuple[int, int],
        exit_pos: tuple[int, int],
        on_step: Callable[
            [tuple[int, int], set[tuple[int, int]], set[tuple[int, int]], str],
            None
        ] | None = None
    ) -> str:
        """Find the shortest path using A* algorithm."""
        if self.maze is None:
            raise RuntimeError("Maze must be generated before solving")

        if not (0 <= entry[0] < self.width and 0 <= entry[1] < self.height):
            raise ValueError(f"Entry {entry} out of bounds")
        if not (0 <= exit_pos[0] < self.width and
                0 <= exit_pos[1] < self.height):
            raise ValueError(f"Exit {exit_pos} out of bounds")

        return a_star(entry, exit_pos, self.maze, on_step)

    def get_pattern_cells(self) -> list[tuple[int, int]]:
        """Get coordinates of the '42' pattern cells."""
        return self._pattern_cells.copy()

    def to_hex_string(self) -> str:
        """Convert maze to hexadecimal string format."""
        if self.maze is None:
            raise RuntimeError("Maze must be generated first")
        return "\n".join(
            "".join(str(cell) for cell in row) for row in self.maze
        )

    def get_cell(self, x: int, y: int) -> Cell:
        """Get cell at specified coordinates."""
        if self.maze is None:
            raise RuntimeError("Maze must be generated first")
        return self.maze[y][x]

    def reset(self) -> None:
        """Reset the generator."""
        self.maze = None
        self._pattern_cells = []
