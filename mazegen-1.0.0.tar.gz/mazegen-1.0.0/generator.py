"""Maze Generator module.

This module provides the MazeGenerator class for creating random mazes
using DFS or Kruskal algorithms, with A* pathfinding.

This file is auto-generated from src/a_maze_ing sources.
Do not edit directly - modify the source files instead.
"""

import random
from collections.abc import Callable
from heapq import heappush, heappop
from random import choice as random_choice
from random import shuffle as random_shuffle
from mazegen.cell import Cell, CellState


# =============================================================================
# FT Pattern (from algorithms/ft_pattern.py)
# =============================================================================

_FT_PATTERN = [
    [1, 0, 0, 0, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 0, 1, 1, 1],
    [0, 0, 1, 0, 1, 0, 0],
    [0, 0, 1, 0, 1, 1, 1]
]

_FT_PATTERN_WARNED = False


def where_is_ft_pattern(grid: list[list[Cell]]) -> list[tuple[int, int]]:
    if len(grid) < 7 or len(grid[0]) < 9:
        global _FT_PATTERN_WARNED
        if not _FT_PATTERN_WARNED:
            print("Error: Maze too small for '42' pattern, skipping pattern.")
            _FT_PATTERN_WARNED = True
        return []
    result = []
    pattern_top_left = (len(grid[0]) / 2 - 3, len(grid) / 2 - 2)
    for y in range(len(_FT_PATTERN)):
        for x in range(len(_FT_PATTERN[y])):
            top_left_x, top_left_y = pattern_top_left
            if _FT_PATTERN[y][x] == 1:
                result.append((int(top_left_x + x), int(top_left_y + y)))
    return result


# =============================================================================
# DFS Algorithm (from algorithms/dfs.py)
# =============================================================================

def _get_neighbors(
        coordinates: tuple[int, int],
        grid: list[list[Cell]]
) -> list[Cell]:
    x, y = coordinates
    neighbors = []
    height = len(grid)
    width = len(grid[0]) if height > 0 else 0

    if y > 0 and grid[y - 1][x]:
        neighbors.append(grid[y - 1][x])
    if y < height - 1 and grid[y + 1][x]:
        neighbors.append(grid[y + 1][x])
    if x > 0 and grid[y][x - 1]:
        neighbors.append(grid[y][x - 1])
    if x < width - 1 and grid[y][x + 1]:
        neighbors.append(grid[y][x + 1])

    return neighbors


def _generate_full_grid(width: int, height: int) -> list[list[Cell]]:
    grid = [
        [
            Cell(
                CellState.UNVISITED,
                True, True, True, True,
                (x, y)
            ) for x in range(width)
        ] for y in range(height)
    ]
    for x, y in where_is_ft_pattern(grid):
        grid[y][x].state = CellState.VISITED
    return grid


def _remove_walls_between(cell1: Cell, cell2: Cell) -> None:
    """
    Removes the walls between two adjacent cells.
    """
    x1, y1 = cell1.coordinates
    x2, y2 = cell2.coordinates

    if x1 == x2:
        if y2 < y1:
            cell1.north = False
            cell2.south = False
        else:
            cell1.south = False
            cell2.north = False

    elif y1 == y2:
        if x2 < x1:
            cell1.west = False
            cell2.east = False
        else:
            cell1.east = False
            cell2.west = False


def generate_dfs(
        config: dict[str, object],
        on_step: Callable[[list[list[Cell]]], None] | None = None
) -> list[list[Cell]]:
    entry = config["ENTRY"]
    assert isinstance(entry, tuple)
    x, y = entry
    width = config["WIDTH"]
    height = config["HEIGHT"]
    assert isinstance(width, int)
    assert isinstance(height, int)
    grid = _generate_full_grid(width, height)
    current = grid[y][x]
    current.state = CellState.VISITED
    stack = [current]
    if on_step:
        on_step(grid)

    while stack:
        current = stack[-1]
        neighbors = [nb for nb in _get_neighbors(current.coordinates, grid)
                     if nb.state != CellState.VISITED]

        if neighbors:
            next_cell = random_choice(neighbors)
            _remove_walls_between(current, next_cell)
            next_cell.state = CellState.VISITED
            stack.append(next_cell)
            if on_step:
                on_step(grid)
        else:
            stack.pop()

    return grid


# =============================================================================
# Kruskal Algorithm (from algorithms/kruskal.py)
# =============================================================================

def _generate_full_grid(width: int, height: int) -> list[list[Cell]]:
    grid = [
        [
            Cell(
                CellState.UNVISITED,
                True, True, True, True,
                (x, y)
            ) for x in range(width)
        ] for y in range(height)
    ]
    for x, y in where_is_ft_pattern(grid):
        grid[y][x].state = CellState.VISITED
    return grid


def _remove_walls_between(cell1: Cell, cell2: Cell) -> None:
    """
    Removes the walls between two adjacent cells.
    """
    x1, y1 = cell1.coordinates
    x2, y2 = cell2.coordinates

    if x1 == x2:
        if y2 < y1:
            cell1.north = False
            cell2.south = False
        else:
            cell1.south = False
            cell2.north = False

    elif y1 == y2:
        if x2 < x1:
            cell1.west = False
            cell2.east = False
        else:
            cell1.east = False
            cell2.west = False


class _DisjointSet:
    def __init__(self, items: list[tuple[int, int]]) -> None:
        self.parent = {item: item for item in items}
        self.rank = {item: 0 for item in items}

    def find(self, item: tuple[int, int]) -> tuple[int, int]:
        parent = self.parent[item]
        if parent != item:
            self.parent[item] = self.find(parent)
        return self.parent[item]

    def union(self, a: tuple[int, int], b: tuple[int, int]) -> bool:
        root_a = self.find(a)
        root_b = self.find(b)
        if root_a == root_b:
            return False
        rank_a = self.rank[root_a]
        rank_b = self.rank[root_b]
        if rank_a < rank_b:
            self.parent[root_a] = root_b
        elif rank_a > rank_b:
            self.parent[root_b] = root_a
        else:
            self.parent[root_b] = root_a
            self.rank[root_a] += 1
        return True


def _get_edges(grid: list[list[Cell]]) -> list[tuple[Cell, Cell]]:
    edges: list[tuple[Cell, Cell]] = []
    height = len(grid)
    width = len(grid[0]) if height > 0 else 0

    for y in range(height):
        for x in range(width):
            cell = grid[y][x]
            if cell.state == CellState.VISITED:
                continue
            if y + 1 < height:
                neighbor = grid[y + 1][x]
                if neighbor.state != CellState.VISITED:
                    edges.append((cell, neighbor))
            if x + 1 < width:
                neighbor = grid[y][x + 1]
                if neighbor.state != CellState.VISITED:
                    edges.append((cell, neighbor))

    return edges


def generate_kruskal(
        config: dict[str, object],
        on_step: Callable[[list[list[Cell]]], None] | None = None
) -> list[list[Cell]]:
    width = config["WIDTH"]
    height = config["HEIGHT"]
    assert isinstance(width, int)
    assert isinstance(height, int)

    grid = _generate_full_grid(width, height)
    edges = _get_edges(grid)
    random_shuffle(edges)

    items = [
        cell.coordinates
        for row in grid
        for cell in row
        if cell.state != CellState.VISITED
    ]
    disjoint_set = _DisjointSet(items)

    if on_step:
        on_step(grid)

    for cell1, cell2 in edges:
        if disjoint_set.union(cell1.coordinates, cell2.coordinates):
            _remove_walls_between(cell1, cell2)
            if on_step:
                on_step(grid)

    return grid


# =============================================================================
# A* Pathfinding (from algorithms/a_star.py)
# =============================================================================

def _manhattan_distance(pos: tuple[int, int], goal: tuple[int, int]) -> int:
    return abs(pos[0] - goal[0]) + abs(pos[1] - goal[1])


def _get_accessible_neighbors(
        cell: Cell, grid: list[list[Cell]]
) -> list[tuple[Cell, str]]:
    x, y = cell.coordinates
    height = len(grid)
    width = len(grid[0]) if height > 0 else 0
    neighbors = []

    if not cell.north and y > 0:
        neighbors.append((grid[y - 1][x], 'N'))
    if not cell.south and y < height - 1:
        neighbors.append((grid[y + 1][x], 'S'))
    if not cell.west and x > 0:
        neighbors.append((grid[y][x - 1], 'W'))
    if not cell.east and x < width - 1:
        neighbors.append((grid[y][x + 1], 'E'))

    return neighbors


def a_star(
        entry: tuple[int, int],
        exit: tuple[int, int],
        grid: list[list[Cell]],
        on_step: Callable[
            [tuple[int, int], set[tuple[int, int]], set[tuple[int, int]], str],
            None
        ] | None = None
) -> str:
    if not grid or not grid[0]:
        return ""

    def reconstruct_path(
            came_from: dict[tuple[int, int], tuple[tuple[int, int], str]],
            current: tuple[int, int]
    ) -> str:
        steps: list[str] = []
        while current in came_from:
            previous, direction = came_from[current]
            steps.append(direction)
            current = previous
        steps.reverse()
        return "".join(steps)

    counter = 0
    open_set: list[tuple[int, int, tuple[int, int]]] = []
    heappush(open_set, (0, counter, entry))
    open_positions = {entry}

    g_score = {entry: 0}
    came_from: dict[tuple[int, int], tuple[tuple[int, int], str]] = {}

    closed_set: set[tuple[int, int]] = set()

    while open_set:
        _, _, current_pos = heappop(open_set)

        if current_pos in closed_set:
            continue
        open_positions.discard(current_pos)
        path = reconstruct_path(came_from, current_pos)

        if current_pos == exit:
            if on_step:
                on_step(
                    current_pos,
                    set(open_positions),
                    closed_set | {current_pos},
                    path
                )
            return path

        closed_set.add(current_pos)

        current_x, current_y = current_pos
        current_cell = grid[current_y][current_x]

        for neighbor_cell, direction in (
                _get_accessible_neighbors(current_cell, grid)
        ):
            neighbor_pos = neighbor_cell.coordinates

            if neighbor_pos in closed_set:
                continue

            tentative_g = g_score[current_pos] + 1

            if (neighbor_pos not in g_score or
                    tentative_g < g_score[neighbor_pos]):
                g_score[neighbor_pos] = tentative_g
                came_from[neighbor_pos] = (current_pos, direction)
                f_score = tentative_g + _manhattan_distance(neighbor_pos, exit)
                counter += 1
                heappush(
                    open_set,
                    (f_score, counter, neighbor_pos)
                )
                open_positions.add(neighbor_pos)

        if on_step:
            on_step(
                current_pos,
                set(open_positions),
                set(closed_set),
                path
            )

    return ""


# =============================================================================
# MazeGenerator - Main class (from mazegen_wrapper.py)
# =============================================================================

class MazeGenerator:
    """A configurable maze generator supporting multiple algorithms.

    This class wraps the DFS and Kruskal generation algorithms and A* solver.
    Generated mazes are perfect mazes (exactly one path between any two cells).

    Attributes:
        width: Number of cells horizontally.
        height: Number of cells vertically.
        seed: Random seed for reproducibility.
        algorithm: 'DFS' or 'KRUSKAL'.
        include_pattern: Whether to include the 42 pattern.
        maze: The generated maze grid (None until generate() is called).

    Example:
        >>> from mazegen import MazeGenerator
        >>> gen = MazeGenerator(width=20, height=15, seed=42)
        >>> maze = gen.generate()
        >>> path = gen.solve((0, 0), (19, 14))
    """

    def __init__(
        self,
        width: int = 20,
        height: int = 15,
        seed: int | None = None,
        algorithm: str = "DFS",
        include_pattern: bool = True
    ) -> None:
        if width < 1:
            raise ValueError(f"Width must be at least 1, got {width}")
        if height < 1:
            raise ValueError(f"Height must be at least 1, got {height}")
        if algorithm.upper() not in ("DFS", "KRUSKAL"):
            raise ValueError(
                f"Algorithm must be 'DFS' or 'KRUSKAL', got {algorithm}"
            )

        self.width = width
        self.height = height
        self.seed = seed
        self.algorithm = algorithm.upper()
        self.include_pattern = include_pattern
        self.maze: list[list[Cell]] | None = None
        self._pattern_cells: list[tuple[int, int]] = []

    def generate(
        self,
        entry: tuple[int, int] | None = None,
        on_step: Callable[[list[list[Cell]]], None] | None = None
    ) -> list[list[Cell]]:
        """Generate a new maze."""
        if entry is None:
            entry = (0, 0)

        if not (0 <= entry[0] < self.width and 0 <= entry[1] < self.height):
            raise ValueError(f"Entry {entry} out of bounds")

        if self.seed is not None:
            random.seed(self.seed)

        # Build config dict for algorithm functions
        config = {
            "WIDTH": self.width,
            "HEIGHT": self.height,
            "ENTRY": entry,
            "INCLUDE_PATTERN": self.include_pattern,
        }

        if self.algorithm == "KRUSKAL":
            self.maze = generate_kruskal(config, on_step)
        else:
            self.maze = generate_dfs(config, on_step)

        # Compute pattern cells
        if self.maze:
            self._pattern_cells = where_is_ft_pattern(self.maze)

        return self.maze

    def solve(
        self,
        entry: tuple[int, int],
        exit_pos: tuple[int, int],
        on_step: Callable[
            [tuple[int, int], set[tuple[int, int]], set[tuple[int, int]], str],
            None
        ] | None = None
    ) -> str:
        """Find the shortest path using A* algorithm."""
        if self.maze is None:
            raise RuntimeError("Maze must be generated before solving")

        if not (0 <= entry[0] < self.width and 0 <= entry[1] < self.height):
            raise ValueError(f"Entry {entry} out of bounds")
        if not (0 <= exit_pos[0] < self.width and
                0 <= exit_pos[1] < self.height):
            raise ValueError(f"Exit {exit_pos} out of bounds")

        return a_star(entry, exit_pos, self.maze, on_step)

    def get_pattern_cells(self) -> list[tuple[int, int]]:
        """Get coordinates of the '42' pattern cells."""
        return self._pattern_cells.copy()

    def to_hex_string(self) -> str:
        """Convert maze to hexadecimal string format."""
        if self.maze is None:
            raise RuntimeError("Maze must be generated first")
        return "\n".join(
            "".join(str(cell) for cell in row) for row in self.maze
        )

    def get_cell(self, x: int, y: int) -> Cell:
        """Get cell at specified coordinates."""
        if self.maze is None:
            raise RuntimeError("Maze must be generated first")
        return self.maze[y][x]

    def reset(self) -> None:
        """Reset the generator."""
        self.maze = None
        self._pattern_cells = []
